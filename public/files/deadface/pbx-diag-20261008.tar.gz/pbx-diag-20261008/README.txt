PBX diagnostics bundle for INC0041877 (one-way audio on help-line inbound).
Collected from pbx01. tls-keys.log = SSLKEYLOGFILE output from the pjsip TLS transport,
needed by the vendor to read the SIP signalling in the span capture. tls-keys.log.1 is from
yesterday's aborted run (transport was restarted, keys are useless).
DELETE THIS BUNDLE after the vendor confirms receipt. -mk
